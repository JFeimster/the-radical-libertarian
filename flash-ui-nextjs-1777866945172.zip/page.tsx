import React from 'react';
import './styles.css';

export default function Page() {
  return (
    <main className="min-h-screen">
      <div dangerouslySetInnerHTML={{ __html: `
<div class="grain-overlay"></div>

    <header>
        <div class="logo">T.R.L.</div>
        <nav>
            <a href="#">Essays</a>
            <a href="#">Manifesto</a>
            <a href="#">Podcast</a>
            <a href="#">Join</a>
        </nav>
    </header>

    <section class="hero">
        <div class="sticker">UNFILTERED & UNGOVERNABLE</div>
        <h1>FREEDOM IS NOT<br>SUPPOSED TO BE<br><span style="color:var(--red)">COMFORTABLE.</span></h1>
        <p>Essays, podcasts, rants, and philosophical grenades for people who distrust both the boot and the person begging to polish it.</p>
        <a href="#" class="btn">READ THE MANIFESTO</a>
    </section>

    <div class="marquee">
        <span>Decentralize Everything — Personal Sovereignty is Absolute — Kill the NPC Narrative — The State is a Fiction — Question the Consensus — Code is Speech —</span>
    </div>

    <h2 class="section-title">The Manifesto</h2>
    <section class="manifesto-grid">
        <div class="manifesto-card">
            <h3>01. Sovereignty</h3>
            <p>The individual is the smallest minority. Any system that sacrifices the one for the "many" is a meat-grinder by design. We claim absolute ownership of self.</p>
        </div>
        <div class="manifesto-card">
            <h3>02. Decentralization</h3>
            <p>Concentrated power is a magnetic pole for sociopaths. We build tools to fragment authority until it disappears. Exit > Voice.</p>
        </div>
        <div class="manifesto-card">
            <h3>03. Anti-Censorship</h3>
            <p>Words are not violence. <span class="redacted">Censorship</span> is the first tool of the tyrant and the last refuge of the intellectually bankrupt.</p>
        </div>
    </section>

    <div class="torn-edge"></div>

    <section class="essays">
        <h2 class="heavy" style="font-size: 3rem; margin-bottom: 40px;">Latest Rants</h2>
        <a href="#" class="essay-row">
            <h4>The Architecture of Digital Serfdom</h4>
            <span class="essay-meta">ESSAY / 12.04.24</span>
        </a>
        <a href="#" class="essay-row">
            <h4>Why Your Local Politician Is a Hologram</h4>
            <span class="essay-meta">RANT / 11.28.24</span>
        </a>
        <a href="#" class="essay-row">
            <h4>Cryptographic Secession: The Only Way Out</h4>
            <span class="essay-meta">PHILOSOPHY / 11.15.24</span>
        </a>
    </section>

    <section class="podcast-section">
        <div class="podcast-art"></div>
        <div class="podcast-content">
            <h2 class="heavy" style="font-size: 3rem;">The Signal Fire Podcast</h2>
            <p style="font-size: 1.4rem; margin: 20px 0;">Conversations with dissidents, cypherpunks, and economic heretics. No scripts. No sponsors. No mercy for bad ideas.</p>
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <span style="border: 2px solid var(--black); padding: 5px 10px; font-family: 'Space Mono'; font-weight: bold;">EP. 84: AGORISM IN THE AGE OF AI</span>
                <span style="border: 2px solid var(--black); padding: 5px 10px; font-family: 'Space Mono'; font-weight: bold;">EP. 83: THE DEATH OF THE SOCIAL CONTRACT</span>
            </div>
            <br><br>
            <a href="#" class="btn" style="font-size: 1rem; padding: 10px 20px;">LISTEN ON THE DARKNET</a>
        </div>
    </section>

    <section class="enemies-list">
        <h2 class="heavy" style="margin-bottom: 30px;">Enemies of Lazy Thinking</h2>
        <div class="enemy-item">The Two-Party Mirage</div>
        <div class="enemy-item">Bureaucratic Inertia</div>
        <div class="enemy-item">The Surveillance State</div>
        <div class="enemy-item">Manufactured Consent</div>
        <div class="enemy-item">Central Bank Alchemy</div>
    </section>

    <section class="newsletter">
        <h2 class="heavy" style="font-size: 2.5rem;">Get the Philosophical Grenades.</h2>
        <p style="margin-bottom: 30px; font-weight: bold;">Once a week. No spam. Just radical clarity.</p>
        <form>
            <input type="email" placeholder="YOUR_EMAIL@DISSIDENT.COM"><br>
            <button type="button" class="btn">SUBSCRIBE TO REVOLUTION</button>
        </form>
    </section>

    <footer>
        <p>© THE RADICAL LIBERTARIAN. NO RIGHTS RESERVED. COPYING IS A VIRTUE.</p>
        <p style="margin-top: 10px; opacity: 0.5;">BUILT FOR THE END OF THE WORLD AS WE KNOW IT.</p>
    </footer>
      ` }} />
    </main>
  );
}